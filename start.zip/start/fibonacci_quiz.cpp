#include <iostream> // cout, cin
#include <string>   // string
#include <cstdlib>  // rand
#include "fibonacci.h" // fibonacci_number

int main(int argc, char **argv)
{
	// Greeting, get name
	std::string name;
	std::cout << "Welcome to Fibonacci Quiz! What's your name?" << std::endl;
	std::cin >> name;

	// Set RNG seed
	srand(56781234);

	// Start the quiz loop
	bool correct = false;
	do
	{
		if (correct)
			std::cout << "Congratulations " << name << "! You are correct." << std::endl;

		// Generate a random position 1-10
		int position = rand() % 10;

		correct = false;

		std::cout << name << ", what is the value at position " << position << " in the Fibonacci sequence?" << std::endl;
		std::string guess;
		std::cin >> guess;

		if (std::stoi(guess) == fibonacci_number(position))
			correct = true;

	} while (correct);

	std::cout << "Sorry " << name << ", that's not the correct answer. Goodbye!" << std::endl;
}
