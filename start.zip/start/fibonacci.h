// Calculate value of <position>th position in fibonacci sequence 
int fibonacci_number(int position)
{
	if (position == 0)
		return 0;
	if (position == 1)
		return 1;
	return fibonacci_number(position - 2) + fibonacci_number(position - 1);
}

